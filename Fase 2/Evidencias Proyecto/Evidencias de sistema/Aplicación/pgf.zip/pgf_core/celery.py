# pgf_core/celery.py
import os
from celery import Celery
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "pgf_core.settings")
app = Celery("pgf")
app.config_from_object("django.conf:settings", namespace="CELERY")
app.autodiscover_tasks()
