import pytest
from django.urls import reverse
from rest_framework.test import APIClient
from apps.users.models import User

@pytest.mark.django_db
def test_register_and_me_flow():
    client = APIClient()
    # registro
    payload = {
        "username": "u1",
        "email": "u1@example.com",
        "first_name": "U",
        "last_name": "Uno",
        "password": "S3gura123!!",
        "password2": "S3gura123!!"
    }
    r = client.post("/api/users/", payload, format="json")
    assert r.status_code in (200, 201), r.data

    # login
    r = client.post("/api/auth/token/", {"username":"u1","password":"S3gura123!!"}, format="json")
    assert r.status_code == 200, r.data
    token = r.data["access"]

    # me
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    r = client.get("/api/users/me/")
    assert r.status_code == 200
    assert r.data["username"] == "u1"
