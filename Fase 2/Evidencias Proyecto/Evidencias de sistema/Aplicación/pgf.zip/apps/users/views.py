from django.shortcuts import render

from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import User, Profile
from .serializers import UserSerializer, ProfileSerializer
from .permissions import UserPermission

class UserViewSet(viewsets.ModelViewSet):
    """
    ViewSet para gestionar Usuarios.
    - El registro es público.
    - La gestión (listar, editar, borrar) es solo para admins/supervisores.
    - Un usuario puede editar sus propios datos.
    """
    queryset = User.objects.all().order_by('id')
    serializer_class = UserSerializer
    permission_classes = [UserPermission]

    # Esta es la acción para /api/users/me/
    @action(detail=False, methods=['get', 'put', 'patch'], permission_classes=[permissions.IsAuthenticated])
    def me(self, request, *args, **kwargs):
        self.kwargs['pk'] = request.user.pk
        if request.method == 'GET':
            return self.retrieve(request, *args, **kwargs)
        elif request.method in ['PUT', 'PATCH']:
            return self.update(request, *args, **kwargs)

class ProfileViewSet(viewsets.ModelViewSet):
    """
    ViewSet para perfiles. Generalmente se accede a través del endpoint /me/.
    """
    queryset = Profile.objects.all()
    serializer_class = ProfileSerializer
    permission_classes = [permissions.IsAuthenticated] # Añade permisos más granulares si es necesario

    def get_queryset(self):
        # Un usuario solo debería ver su propio perfil, a menos que sea admin
        if self.request.user.is_staff:
            return Profile.objects.all()
        return Profile.objects.filter(user=self.request.user)