from django.urls import path
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView, TokenVerifyView

class AuthIndexView(APIView):
    authentication_classes = []  # público
    permission_classes = []

    def get(self, request):
        return Response({
            "endpoints": {
                "token": "/api/auth/token/ (POST)",
                "refresh": "/api/auth/token/refresh/ (POST)",
                "verify": "/api/auth/token/verify/ (POST)"
            }
        })

urlpatterns = [
    path("", AuthIndexView.as_view(), name="auth_index"),              # <— NUEVO: GET /api/auth/
    path("token/", TokenObtainPairView.as_view(), name="token_obtain_pair"),
    path("token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("token/verify/", TokenVerifyView.as_view(), name="token_verify"),
]
