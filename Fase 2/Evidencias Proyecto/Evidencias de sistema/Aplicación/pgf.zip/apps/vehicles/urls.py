from rest_framework.routers import DefaultRouter
from .views import VehiculoViewSet

router = DefaultRouter()
router.register(r"", VehiculoViewSet, basename="vehiculo")

urlpatterns = router.urls
# Nota: la ruta base es /api/vehicles/