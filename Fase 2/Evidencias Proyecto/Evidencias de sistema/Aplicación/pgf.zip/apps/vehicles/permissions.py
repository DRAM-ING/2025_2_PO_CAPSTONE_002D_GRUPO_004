from rest_framework.permissions import BasePermission, SAFE_METHODS

def _role(user):
    return getattr(user, "rol", None)

class VehiclePermission(BasePermission):
    """Read autenticado; modificar solo SUPERVISOR/ADMIN."""
    message = "Solo SUPERVISOR/ADMIN pueden modificar vehículos."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user and request.user.is_authenticated
        return _role(request.user) in ("SUPERVISOR", "ADMIN")
