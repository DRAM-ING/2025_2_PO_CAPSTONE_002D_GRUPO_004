from rest_framework.permissions import BasePermission, SAFE_METHODS

def _role(user): return getattr(user, "rol", None)
def _is_admin(u): return _role(u) == "ADMIN"
def _is_supervisor(u): return _role(u) == "SUPERVISOR" or _is_admin(u)
def _is_mechanic(u): return _role(u) == "MECANICO"
def _is_guard(u): return _role(u) == "GUARDIA"
def _is_sponsor(u): return _role(u) == "SPONSOR"

class WorkOrderPermission(BasePermission):
    """Read: auth; Create: GUARDIA/SUPERVISOR; Edit/Close: SUPERVISOR/ADMIN."""
    message = "Permisos insuficientes para operar sobre Órdenes de Trabajo."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user and request.user.is_authenticated
        if request.method == "POST":
            return _is_guard(request.user) or _is_supervisor(request.user)
        return _is_supervisor(request.user)

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        if request.method in ("PATCH", "PUT"):
            if "estado" in getattr(request, "data", {}):
                if request.data.get("estado") == "CERRADA":
                    return _is_supervisor(request.user)
            return _is_supervisor(request.user)
        if request.method == "DELETE":
            return _is_supervisor(request.user)
        return False

class ItemPermission(BasePermission):
    """CRUD de Items de OT: Mecánico o Supervisor"""
    message = "Solo MECANICO o SUPERVISOR pueden modificar Items de OT."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user.is_authenticated
        return _is_mechanic(request.user) or _is_supervisor(request.user)

class PresupuestoPermission(BasePermission):
    """Crear/editar presupuesto: Supervisor/Admin. Lectura: autenticado."""
    message = "Solo SUPERVISOR/ADMIN pueden modificar Presupuestos."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user.is_authenticated
        return _is_supervisor(request.user)

class DetallePresupPermission(BasePermission):
    """Modificar detalle: Supervisor/Admin."""
    message = "Solo SUPERVISOR/ADMIN pueden modificar Detalle de Presupuesto."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user.is_authenticated
        return _is_supervisor(request.user)

class AprobacionPermission(BasePermission):
    """Crear: Supervisor/Admin. Resolver (PATCH): Sponsor (o Supervisor)."""
    message = "Permisos insuficientes para gestionar aprobaciones."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user.is_authenticated
        if request.method == "POST":
            return _is_supervisor(request.user)
        if request.method in ("PATCH", "PUT"):
            return _is_sponsor(request.user) or _is_supervisor(request.user)
        if request.method == "DELETE":
            return _is_supervisor(request.user)
        return False

class PausaPermission(BasePermission):
    """Crear: Mecánico/Supervisor. Editar/Borrar: creador o Supervisor/Admin. Lectura: autenticado."""
    message = "Permisos insuficientes para gestionar Pausas."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user.is_authenticated
        if request.method == "POST":
            return _is_mechanic(request.user) or _is_supervisor(request.user)
        return request.user.is_authenticated

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        if request.method in ("PATCH", "PUT", "DELETE"):
            return getattr(obj, "usuario_id", None) == getattr(request.user, "id", None) or _is_supervisor(request.user)
        return False

class ChecklistPermission(BasePermission):
    """Crear/editar checklist: Supervisor/Admin. Lectura: autenticado."""
    message = "Solo SUPERVISOR/ADMIN pueden registrar o editar Checklists."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user.is_authenticated
        return _is_supervisor(request.user)

class EvidenciaPermission(BasePermission):
    """Crear: Mecánico/Supervisor. Eliminar: Supervisor/Admin. Lectura: autenticado."""
    message = "Permisos insuficientes para operar Evidencias."

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return request.user.is_authenticated
        if request.method == "POST":
            return _is_mechanic(request.user) or _is_supervisor(request.user)
        if request.method == "DELETE":
            return _is_supervisor(request.user)
        return _is_supervisor(request.user)
