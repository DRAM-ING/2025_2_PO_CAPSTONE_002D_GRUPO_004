# apps/workorders/urls.py
from rest_framework.routers import DefaultRouter
from .views import *

router = DefaultRouter()
router.register(r"ordenes", OrdenTrabajoViewSet, basename="orden")
router.register(r"items", ItemOTViewSet, basename="item")
router.register(r"presupuestos", PresupuestoViewSet, basename="presupuesto")
router.register(r"detalles-presupuesto", DetallePresupViewSet, basename="detalle-presupuesto")
router.register(r"aprobaciones", AprobacionViewSet, basename="aprobacion")
router.register(r"pausas", PausaViewSet, basename="pausa")
router.register(r"checklists", ChecklistViewSet, basename="checklist")
router.register(r"evidencias", EvidenciaViewSet, basename="evidencia")
urlpatterns = router.urls
# Agrega otras rutas si es necesario
# urlpatterns += [...]  